---
name: Bug Report
about: If something doesn't work as expected.
title: "[Bug] "
labels: bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**System (please complete the following information):**
 - Operating System: 
 - Java Version:
 - Randomizer Version: 

**Additional context**
Add any other context about the problem here.
